Raytracer ply2ray Converting Tool
----------------

ply2ray is a simple tool that convert a .ply file into a .ray file. The commond format is

ply2ray input_ply_file output_ray_file

You can use MeshLab to view all the .ply files.