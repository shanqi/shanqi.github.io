Here are the sample scenes that are included with the project.

Feel free to look them over and become familiar with their format (if
you don't do it sooner, you will have to do it later when you make
your artifact). The ray traced rendering of these scenes for a
recursion depth of 3 are also included with the .ray files.

The scenes in the "simple" directory are the ones you want to start
testing your code with before moving to more complex examples.

The scenes in the "trimeshes" directory include triangle meshes, some of
them fairly complex.

The scenes in the "more" directory are a few more examples.

