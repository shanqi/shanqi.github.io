#include "vault.h"
const char* SHADER_KEY = NULL;
int SHADER_COUNT = 0;
const char* SHADER_FILENAMES[1];
const char* SHADER_DATA[1];